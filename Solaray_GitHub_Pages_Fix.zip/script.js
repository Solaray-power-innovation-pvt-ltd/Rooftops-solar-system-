document.addEventListener("DOMContentLoaded", () => {
  const toggle = document.getElementById("menuToggle");
  const nav = document.getElementById("nav");
  const form = document.getElementById("enquiryForm");
  const status = document.getElementById("formStatus");
  document.getElementById("year").textContent = new Date().getFullYear();

  toggle.addEventListener("click", () => {
    const open = nav.classList.toggle("open");
    toggle.setAttribute("aria-expanded", String(open));
    toggle.textContent = open ? "✕ Close" : "☰ Menu";
  });
  nav.querySelectorAll('a[href^="#"]').forEach(link => link.addEventListener("click", () => {
    nav.classList.remove("open");
    toggle.setAttribute("aria-expanded", "false");
    toggle.textContent = "☰ Menu";
  }));

  form.addEventListener("submit", event => {
    event.preventDefault();
    if (!form.reportValidity()) return;
    const name = document.getElementById("name").value.trim();
    const phone = document.getElementById("phone").value.trim();
    const interest = document.getElementById("interest").value;
    const message = document.getElementById("message").value.trim();
    const enquiry = [
      "Hello Solaray Power Innovations Private Limited,",
      "I would like to make an enquiry.", "",
      `Name: ${name}`, `Phone: ${phone}`, `Interested in: ${interest}`,
      message ? `Message: ${message}` : ""
    ].filter(Boolean).join("\n");
    const url = "https://wa.me/919366495875?text=" + encodeURIComponent(enquiry);
    status.textContent = "If WhatsApp did not open, use the link below.";
    const link = document.createElement("a");
    link.href = url; link.target = "_blank"; link.rel = "noopener noreferrer";
    link.textContent = " Tap here to open WhatsApp";
    status.appendChild(link);
    window.open(url, "_blank", "noopener,noreferrer");
  });
});