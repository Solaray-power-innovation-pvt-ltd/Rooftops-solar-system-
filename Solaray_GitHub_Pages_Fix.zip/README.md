# Solaray GitHub Pages Fix

This version is designed for GitHub Pages and does not need Node.js.

## Files
- `index.html` — main page and contact section
- `styles.css` — responsive styling
- `script.js` — mobile menu and WhatsApp enquiry form
- `solaray-logo.jpg` and `solaray-wordmark.jpg` — logo assets

## Fix and publish
1. Extract this ZIP.
2. Open the GitHub repository `Rooftops-solar-system`.
3. Replace `index.html`, `styles.css`, and `script.js` with these files.
4. Upload both JPG logo images to the repository root.
5. Commit the changes to the branch/folder selected under **Settings → Pages**.
6. Wait for the deployment to complete, then refresh the site.

## What is fixed
- Relative file paths work on a GitHub Pages project URL such as `/Rooftops-solar-system/`.
- Contact links point to the `id="contact"` section.
- The enquiry form opens WhatsApp with a prefilled message; visitors must press Send in WhatsApp.
- A fallback WhatsApp link appears if the browser blocks a new tab.

## Company details
South Barjala, Agartala Airport Road, Opposite HP Petrol Pump, Bhati Abhoynagar, Agartala, Tripura 799002  
+91 93664 95875 / +91 94364 52537  
Monday–Saturday, 9:00 AM–6:00 PM; Sunday closed.

Verify company details before publishing. GitHub Pages is static hosting, so a form cannot store submissions without a separate backend or form service.
