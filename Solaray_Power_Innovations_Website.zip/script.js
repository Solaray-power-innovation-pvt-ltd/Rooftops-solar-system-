document.addEventListener("DOMContentLoaded", () => {
  const menuToggle = document.getElementById("menuToggle");
  const mainNav = document.getElementById("mainNav");
  const form = document.getElementById("enquiryForm");
  const status = document.getElementById("formStatus");

  document.getElementById("year").textContent = new Date().getFullYear();

  menuToggle.addEventListener("click", () => {
    const isOpen = mainNav.classList.toggle("open");
    menuToggle.setAttribute("aria-expanded", String(isOpen));
    menuToggle.textContent = isOpen ? "✕" : "☰";
  });

  mainNav.querySelectorAll("a").forEach(link => {
    link.addEventListener("click", () => {
      mainNav.classList.remove("open");
      menuToggle.setAttribute("aria-expanded", "false");
      menuToggle.textContent = "☰";
    });
  });

  form.addEventListener("submit", event => {
    event.preventDefault();
    if (!form.reportValidity()) return;

    const name = document.getElementById("name").value.trim();
    const phone = document.getElementById("phone").value.trim();
    const interest = document.getElementById("interest").value;
    const message = document.getElementById("message").value.trim();

    const enquiry = [
      "Hello Solaray Power Innovations Private Limited,",
      "I would like to make an enquiry.",
      "",
      `Name: ${name}`,
      `Phone: ${phone}`,
      `Interested in: ${interest}`,
      message ? `Message: ${message}` : ""
    ].filter(Boolean).join("\n");

    // Opens WhatsApp with the enquiry prefilled; the user chooses whether to send it.
    const whatsappUrl = `https://wa.me/919366495875?text=${encodeURIComponent(enquiry)}`;
    status.textContent = "Opening WhatsApp with your enquiry. Please review and send it there.";
    window.open(whatsappUrl, "_blank", "noopener,noreferrer");
  });
});
